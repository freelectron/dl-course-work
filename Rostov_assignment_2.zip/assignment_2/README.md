# Assignment 2 - RNNs, GraphNNs

- The PDF document in this folder contains all the questions. 
- For the first and second part you have to implement RNN's in PyTorch. 
- For the third part you will have to answer pen and paper questions about GraphNNs
- All code must be added to the existing files in this repository. 
- Unlike the previous assignment, there are no unit tests this time.  
- Questions can be asked on Piazza.
- The deadline for this assignment is **May 1st, 2019 at 23:59**.